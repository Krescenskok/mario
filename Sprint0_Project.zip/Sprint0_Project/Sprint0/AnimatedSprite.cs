﻿using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0
{
    public class AnimatedSprite : ISprite
    {

        public Texture2D texture { get; set; }
        public int Rows { get; set; }
        public int Columns { get; set; }

        public int CurrentFrame;
        private int TotalFrames;

        public AnimatedSprite()
        {
            Rows = 2;
            Columns = 4;
            CurrentFrame = 0;
            TotalFrames = Rows * Columns;
        }

        
        public void Draw(SpriteBatch spriteBatch, GameTime gameTime, Vector2 location)
        {
            if (CurrentFrame == TotalFrames)
                CurrentFrame = 0;

            int width = texture.Width / Columns;
            int height = texture.Height / Rows;
            int row = (int)((float)CurrentFrame / (float)Columns);
            int column = CurrentFrame % Columns;

            Rectangle sourceRectangle = new Rectangle(width * column, height * row, width, height);
            Rectangle destinationRectangle = new Rectangle((int)location.X - width / 2, (int)location.Y - height / 2, width, height);

            spriteBatch.Draw(texture, destinationRectangle, sourceRectangle, Color.White);
        }

        public void Load(Game game)
        {
            texture = game.Content.Load<Texture2D>("marioOneDirection");
        }

    }
}
