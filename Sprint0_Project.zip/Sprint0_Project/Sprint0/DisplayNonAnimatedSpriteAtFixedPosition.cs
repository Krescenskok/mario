﻿using System;
using System.Diagnostics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Sprint0
{
    public class DisplayNonAnimatedSpriteAtFixedPositionCommand : ICommand
    {
        private AnimatedSprite sprite = new AnimatedSprite();

        public DisplayNonAnimatedSpriteAtFixedPositionCommand()
        {
        }

        public void DoInit(Game game)
        {
            sprite.Load(game);
        }

        public void ExecuteCommand(Game game, GameTime gameTime, SpriteBatch spriteBatch )
        {
        
            sprite.Draw(spriteBatch, gameTime,new Vector2(game.GraphicsDevice.Viewport.Width / 2, game.GraphicsDevice.Viewport.Height / 2));

        }
    }
}
